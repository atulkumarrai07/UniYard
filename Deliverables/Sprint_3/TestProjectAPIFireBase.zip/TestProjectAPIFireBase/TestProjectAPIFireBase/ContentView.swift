//
//  ContentView.swift
//  TestProjectAPIFireBase
//
//  Created by Atul Kumar Rai on 10/19/21.
//

import SwiftUI
import FirebaseFirestore

var post1:Post = Post(id: "P0001", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
var post2:Post = Post(id: "P0002", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
struct ContentView: View {
  var viewModel: ViewModel = ViewModel()
  
  var user1:User = User(id: "U00003", email: "mhao@andrew.cmu.edu", first_name: "Min", last_name: "Hao", campus_location: "Pittsburgh", saved_post_list: [], my_post_list: [post1, post2], date_joined: Timestamp.init(), suggestion_preference: "Any", user_status: "Active")
  
    var body: some View {
      NavigationView{
        Text("Hello, world!")
            .padding()
      }.onAppear(){
        self.viewModel.addUser(user: user1)
      }
        
    }
  
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
