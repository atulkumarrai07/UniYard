//
//  ViewModel.swift
//  TestProjectAPIFireBase
//
//  Created by Atul Kumar Rai on 10/20/21.
//

import Foundation
import FirebaseFirestore

class ViewModel
{
  private let database = Firestore.firestore()
  
  func addUser(){
    var user = User(email: <#T##String#>, first_name: <#T##String#>, last_name: <#T##String#>, campus_location: <#T##String#>, saved_post_list: <#T##[Post]#>, my_post_list: <#T##[Post]#>, date_joined: <#T##Timestamp#>, suggestion_preference: <#T##String#>, user_status: <#T##String#>)
    database.collection("Users").document(user.id).setData(user.dictionary)
    print("Users loaded")
  }
  
  func addPost(post:Post) {
    database.collection("Posts").document(post.id).setData(post.dictionary)
    print("Posts loaded")
  }
  
  func addItems(item) -> <#return type#> {
    <#function body#>
  }
}
