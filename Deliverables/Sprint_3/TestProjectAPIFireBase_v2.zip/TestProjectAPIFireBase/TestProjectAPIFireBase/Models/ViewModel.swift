//
//  ViewModel.swift
//  TestProjectAPIFireBase
//
//  Created by Atul Kumar Rai on 10/20/21.
//

import Foundation
import FirebaseFirestore

class ViewModel
{
  private let database = Firestore.firestore()
  
  func addUser(){
    let user1=User(id: "U00001",email: "aaratric@andrew.cmu.edu", first_name: "Aaratrika", last_name: "Chakraborty", campus_location: "Pittsburgh", saved_post_list: ["P00002","P00003"], my_post_list: ["P00001"], date_joined: Timestamp.init(), suggestion_preference: "Items", user_status: true)
    database.collection("Users").document(user1.id).setData(user1.dictionary)
    let user2=User(id: "U00002",email: "atulkr@andrew.cmu.edu", first_name: "Atul", last_name: "Rai", campus_location: "Pittsburgh", saved_post_list: ["P00001","P00003"], my_post_list: ["P00002"], date_joined: Timestamp.init(), suggestion_preference: "Apartments", user_status: true)
    database.collection("Users").document(user2.id).setData(user2.dictionary)
    let user3=User(id: "U00003",email: "mhao@andrew.cmu.edu", first_name: "Iris", last_name: "Hao", campus_location: "Pittsburgh", saved_post_list: ["P00001","P00002","P00004"], my_post_list: ["P00003"], date_joined: Timestamp.init(), suggestion_preference: "Any", user_status: true)
    database.collection("Users").document(user3.id).setData(user3.dictionary)
    let user4=User(id: "U00004",email: "johndoe@andrew.cmu.edu", first_name: "John", last_name: "Doe", campus_location: "Pittsburgh", saved_post_list: ["P00002","P00003"], my_post_list: ["P00004"], date_joined: Timestamp.init(), suggestion_preference: "Any", user_status: true)
    database.collection("Users").document(user4.id).setData(user4.dictionary)
    print("Users loaded")
  }
  
  func addPost(post:Post) {
    let post1 = Post(id: "P00001", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
    let post2 = Post(id: "P00002", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
    let post3 = Post(id: "P00003", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
    let post4 = Post(id: "P00004", last_modified_timestamp: Timestamp.init(), Availability: "Available", post_creation_date: Timestamp.init())
    database.collection("Posts").document(post1.id).setData(post1.dictionary)
    database.collection("Posts").document(post2.id).setData(post2.dictionary)
    database.collection("Posts").document(post3.id).setData(post3.dictionary)
    database.collection("Posts").document(post4.id).setData(post4.dictionary)
    print("Posts loaded")
  }
  
  func addItems(item: Item) {
    let item1 = Item(id: "I00001", post_id: "P00001", item_title: "Lamp", item_description: "A lamp for the study table", item_category: "Electronics", condition: "Almost new", price: 15.90, images: ["https://..jpg"], zip_code: "15213", delivery: true, pickup_location: "3229 Hardie Way")
    let item2 = Item(id: "I00002", post_id: "P00004", item_title: "Vacuum Cleaner", item_description: "1 year old vacuum cleaner with auto detection technology available at reasonable price.", item_category: "Cleaning-Appliance", condition: "New", price: 19.00, images: ["https://..jpg"], zip_code: "15213", delivery: false, pickup_location: "123 Forbes Avenue, Pittburgh")
    database.collection("Items").document(item1.id).setData(item1.dictionary)
    database.collection("Items").document(item2.id).setData(item2.dictionary)
    print("Items loaded")
  }
  
  func addRental(rental:Rental) {
    let rental1 = Rental(id: "R00001", post_id: "P00002", inquiry_title: "Looking for 1 bed, 1 bath apartment at Shadyside", property_type: "Apartment", property_description: "Great Location and well connected. Message me for more details..", num_bed: 1, num_bath: 1, sqft: 0, max_rent: "$1200/month" ,from_date: "Dec 31, 2021", to_date: "March 31, 2022", washer_dryer: true, pet_friendly: true, rent_amount: 0, rent_currency: 0, amenities: ["Parking","Gym"], images: ["https://..jpg"], location: "15213")
    let rental2 = Rental(id: "R00002", post_id: "P00003", inquiry_title: "Looking for 1 bed, 1 bath apartment at Shadyside", property_type: "Apartment", property_description: "Great Location and well connected. Message me for more details..", num_bed: 2, num_bath: 1, sqft: 1234, max_rent: "" ,from_date: "Dec 31, 2021", to_date: "March 31, 2022", washer_dryer: false, pet_friendly: false, rent_amount: 0, rent_currency: 0, amenities: ["Parking","Gym"], images: ["https://..jpg"], location: "123 Forbes Avenue,Pittsburgh")
    database.collection("Rentals").document(rental1.id).setData(rental1.dictionary)
    database.collection("Rentals").document(rental2.id).setData(rental2.dictionary)
    print("Rentals loaded")
  }
  
  func addMessageSequence(messageSequence: Message_Sequence){
    let msgseq1 = Message_Sequence(id: "MS00001", from_id: "U00004", timestamp_msg: Timestamp.init(), content: "Hi Aaratrika", read_status: true)
    let msgseq2 = Message_Sequence(id: "MS00002", from_id: "U00001", timestamp_msg: Timestamp.init(), content: "Hi John", read_status: true)
    database.collection("Message_Sequences").document(msgseq1.id).setData(msgseq1.dictionary)
    database.collection("Message_Sequences").document(msgseq2.id).setData(msgseq2.dictionary)
    print("Message_Sequences loaded")
  }
  
  func addMessage(message: Messages){
    let msg1 = Messages(id: "M00001", post_id: "P00001", user_1: "U00004", user_2: "U00001", sequence: ["MS00001","MS00002"])
    database.collection("Messages").document(msg1.id).setData(msg1.dictionary)
    print("Messages loaded")
  }
  
  func addNotificationSequence(notificationSequence: Notification_Sequence){
    let notfseq1 = Notification_Sequence(id: "NS00001", post_id: "P00002", timestamp_notf: Timestamp.init(), content: "Price of the apartment changed")
    database.collection("Notification_Sequences").document(notfseq1.id).setData(notfseq1.dictionary)
    print("Notification sequences loaded")
  }
  func addNotifications(notifications: Notifications){
    let notification1 = Notifications(id: "N00001", user_id: "U00001", notification_on: true, saved_post_change_alert: true, sequence: ["NS00001"])
    database.collection("Notification_Sequences").document(notification1.id).setData(notification1.dictionary)
    print("notifications loaded")
  }
}
